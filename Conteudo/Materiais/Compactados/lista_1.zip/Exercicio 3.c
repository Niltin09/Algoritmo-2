#include <stdio.h>

float calcularQuadrado(float valor) {
    return valor * valor;
}

int main() {
    float valor;
    printf("Digite um valor: ");
    scanf("%f", &valor);
    float quadrado = calcularQuadrado(valor);
    printf("O quadrado de %.2f é %.2f\n", valor, quadrado);
    return 0;
}