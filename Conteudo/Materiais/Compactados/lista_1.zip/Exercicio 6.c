#include <stdio.h>

int calcularDias(int anos) {
    return anos * 365; // Ignorando anos bissextos
}

int main() {
    int anos;
    printf("Digite sua idade em anos: ");
    scanf("%d", &anos);
    int dias = calcularDias(anos);
    printf("Você viveu aproximadamente %d dias.\n", dias);
    return 0;
}
