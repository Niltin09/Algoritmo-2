#include <stdio.h>

float fahrenheitParaCelsius(float f) {
    return 5 * (f - 32) / 9;
}

int main() {
    float fahrenheit;
    printf("Digite a temperatura em Fahrenheit: ");
    scanf("%f", &fahrenheit);
    float celsius = fahrenheitParaCelsius(fahrenheit);
    printf("Temperatura em Celsius: %.2f\n", celsius);
    return 0;
}
