#include <stdio.h>
#define pi 3.14159265358979323846

float calcularAreaCirculo(float raio) {
    return pi * raio * raio;
}
int main() {
    float raio;
    printf("Digite o raio do círculo: ");
    scanf("%f", &raio);
    float area = calcularAreaCirculo(raio);
    printf("A área do círculo é: %.2f\n", area);
    return 0;
}
