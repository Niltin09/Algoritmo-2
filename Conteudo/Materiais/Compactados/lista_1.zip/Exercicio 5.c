#include <stdio.h>

int converterMinutosParaSegundos(int minutos) {
    return minutos * 60;
}

int main() {
    int minutos;
    printf("Digite o valor em minutos: ");
    scanf("%d", &minutos);
    int segundos = converterMinutosParaSegundos(minutos);
    printf("%d minutos equivalem a %d segundos.\n", minutos, segundos);
    return 0;
}
